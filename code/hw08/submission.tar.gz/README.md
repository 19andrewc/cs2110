# The Bee Game

### How To Play

- Press the 'enter' key to start the game.
- When the game starts, you have 10 seconds to move the bee to the honeycomb.
  - To move the bee, use the 'arrow keys'.
    - UP arrow moves the bee up
    - DOWN arrow moves the bee down
    - LEFT arrow moves the bee to the left
    - RIGHT arrow moves the bee to the right

- If you get the bee to the honeycomb before 10 seconds, you WIN!
- However, if you take too long, you LOSE!.