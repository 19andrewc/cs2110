/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 bee bee.jpeg 
 * Time-stamp: Wednesday 11/10/2021, 17:42:39
 * 
 * Image Information
 * -----------------
 * bee.jpeg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BEE_H
#define BEE_H

extern const unsigned short bee[900];
#define BEE_SIZE 1800
#define BEE_LENGTH 900
#define BEE_WIDTH 30
#define BEE_HEIGHT 30

#endif

