/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=30x30 honeycomb honeycomb.jpeg 
 * Time-stamp: Wednesday 11/10/2021, 19:46:24
 * 
 * Image Information
 * -----------------
 * honeycomb.jpeg 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HONEYCOMB_H
#define HONEYCOMB_H

extern const unsigned short honeycomb[900];
#define HONEYCOMB_SIZE 1800
#define HONEYCOMB_LENGTH 900
#define HONEYCOMB_WIDTH 30
#define HONEYCOMB_HEIGHT 30

#endif

